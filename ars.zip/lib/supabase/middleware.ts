// This file is kept for backwards compatibility but delegates to new implementation
export { updateSession } from "../middleware/auth.middleware"
